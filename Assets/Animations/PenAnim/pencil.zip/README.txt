Writing & erasing pencil sounds.

Licensing: Creative Commons Zero (CC0)

Sources:
- pencil_erase by damsur: https://freesound.org/s/443241/
- pencil_write by NachtmahrTV: https://freesound.org/s/571800/
